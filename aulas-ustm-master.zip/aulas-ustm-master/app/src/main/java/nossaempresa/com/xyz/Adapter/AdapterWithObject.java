package nossaempresa.com.xyz.Adapter;

import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.List;

import nossaempresa.com.xyz.Model.Pessoa;
import nossaempresa.com.xyz.R;

public class AdapterWithObject extends RecyclerView.Adapter<AdapterWithObject.MyViewHolder> {

    private List<Pessoa> pessoaList;

    public class MyViewHolder extends RecyclerView.ViewHolder {
        public TextView nome;

        public MyViewHolder(View view) {
            super(view);
            nome = (TextView) view.findViewById(R.id.title);
        }
    }


    public AdapterWithObject(List<Pessoa> pessoaList) {
        this.pessoaList = pessoaList;
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_pessoa, parent, false);

        return new MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(MyViewHolder holder, int position) {
        Pessoa movie = pessoaList.get(position);
        holder.nome.setText(movie.getNome());
    }

    @Override
    public int getItemCount() {
        return pessoaList.size();
    }
}
